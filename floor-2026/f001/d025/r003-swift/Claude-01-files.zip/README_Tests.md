# m001-hello-SwiftUI — テストコード解説

## ディレクトリ構成

```
m001-hello-SwiftUI/
├── m001_hello_SwiftUIApp.swift   # @main エントリポイント
├── TimerViewModel.swift          # ビジネスロジック（テスト対象の中心）
├── ContentView.swift             # SwiftUI View（表示のみ）
└── Tests/
    ├── TimerViewModelTests.swift  # ユニットテスト（主軸）
    ├── ContentViewTests.swift     # View 結合テスト
    ├── TimerPerformanceTests.swift# パフォーマンステスト
    └── README_Tests.md            # 本ファイル
```

---

## テスト設計の考え方

### なぜ ViewModel を分離するか

SwiftUI の View は直接テストしにくいため、**MVVM パターン**でロジックを
`TimerViewModel` に分離しています。View は `timeString` を受け取って
表示するだけ（パッシブ）にすることで、テストが書きやすくなります。

```
Timer(33ms) ──→ TimerViewModel.tick()
                    └─ format(Date) → timeString: String
                                           └─ ContentView (Text表示のみ)
```

### テスト可能にするための設計ポイント

| 工夫 | 理由 |
|------|------|
| `clock: () -> Date` を DI | 固定時刻でテストできる |
| `format()` を `static` メソッドに | ViewModel インスタンス不要で単体テスト可能 |
| `interval` を DI | テストで短い間隔を指定できる |
| `tick()` を `internal` に | テストから直接呼び出して同期的に確認できる |

---

## 各テストファイルの内容

### TimerViewModelTests.swift（ユニットテスト）

| テスト名 | 検証内容 |
|----------|---------|
| `test_format_returnsCorrectPattern` | 正規表現で `HH:MM:SS.mmm` 形式を確認 |
| `test_format_correctValues` | 時・分・秒・msが正しく変換される |
| `test_format_midnight` | `00:00:00.000` の境界値 |
| `test_format_endOfDay` | `23:59:59.999` の境界値 |
| `test_format_zeroPadding` | 1桁の値が2桁にゼロパディングされる |
| `test_format_millisecondZeroPadding` | 1ms が `001` になる |
| `test_tick_updatesTimeString` | `tick()` で `timeString` が更新される |
| `test_tick_multipleCallsReflectLatestTime` | 複数回 tick で最新値になる |
| `test_initialTimeString_isPlaceholder` | 初期値が `--:--:--.---` |
| `test_start_updatesTimeStringAfterInterval` | 100ms 待つと更新される |
| `test_stop_freezesTimeString` | `stop()` 後は変化しない |
| `test_start_idempotent` | `start()` を2回呼んでも問題ない |
| `test_tick_publishesChange` | `objectWillChange` が発火する |

### ContentViewTests.swift（結合テスト）

| テスト名 | 検証内容 |
|----------|---------|
| `test_contentView_displaysViewModelTimeString` | VM の値が正しければ View も正しい（間接確認） |
| `test_hostingController_viewLoads` | `NSHostingController` でロードしてクラッシュしない |

### TimerPerformanceTests.swift（パフォーマンス）

| テスト名 | 検証内容 |
|----------|---------|
| `test_format_performance` | `format()` を1000回呼んでも高速 |
| `test_tick_performance` | `tick()` を1000回呼んでも高速 |
| `test_timerInterval_approximateSampleCount` | 330ms で ≈10回 tick される |

---

## Xcode でのセットアップ手順

1. Xcode で **File → New → Project** → macOS / App  
   - Product Name: `m001-hello-SwiftUI`  
   - Interface: **SwiftUI**  
   - Language: **Swift**

2. 既存ファイルをプロジェクト内のファイルに置き換える  
   - `TimerViewModel.swift` と `ContentView.swift` をターゲットに追加

3. **File → New → Target** → **Unit Testing Bundle**  
   - テストターゲット名: `m001-hello-SwiftUITests`

4. `Tests/` フォルダの `.swift` を **テストターゲット** に追加

5. `⌘ + U` で全テスト実行

---

## 注意事項

- `@MainActor` をテストクラスに付与しているのは、`TimerViewModel` が
  `@MainActor final class` であるため。
- `ContentViewTests` の `NSHostingController` は **macOS** 専用 API。
  iOS/iPadOS の場合は `UIHostingController` に変えてください。
- パフォーマンステストの許容範囲（±30%）は CI 環境の負荷を考慮した広めの設定です。
  必要に応じて `setUpWithBaseline` で厳密なベースラインを設定してください。
