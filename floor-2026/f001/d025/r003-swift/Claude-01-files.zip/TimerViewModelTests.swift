import XCTest
import Combine
@testable import m001_hello_SwiftUI

// MARK: - Helper

/// テスト用に固定 Date を返すクロックを生成する
private func fixedClock(_ date: Date) -> () -> Date { { date } }

/// "hh:mm:ss.sss" の各フィールドを分解する
private struct TimeParts {
    let hh: Int; let mm: Int; let ss: Int; let sss: Int
    init?(_ s: String) {
        // 想定フォーマット: "HH:MM:SS.mmm"
        let parts = s.split(separator: ":").map(String.init)
        guard parts.count == 3 else { return nil }
        let secParts = parts[2].split(separator: ".").map(String.init)
        guard secParts.count == 2,
              let h  = Int(parts[0]),
              let m  = Int(parts[1]),
              let sc = Int(secParts[0]),
              let ms = Int(secParts[1]) else { return nil }
        hh = h; mm = m; ss = sc; sss = ms
    }
}

// MARK: - Tests

@MainActor
final class TimerViewModelTests: XCTestCase {

    // ────────────────────────────────────────────
    // MARK: 1. フォーマット — 静的メソッドのテスト
    // ────────────────────────────────────────────

    /// 正常系: 任意の Date が "HH:MM:SS.mmm" 形式に変換されること
    func test_format_returnsCorrectPattern() {
        // 2024-06-15 14:05:03.123456789 を DateComponents で組み立てる
        var comps        = DateComponents()
        comps.year       = 2024
        comps.month      = 6
        comps.day        = 15
        comps.hour       = 14
        comps.minute     = 5
        comps.second     = 3
        comps.nanosecond = 123_000_000   // 123 ms

        let date   = Calendar.current.date(from: comps)!
        let result = TimerViewModel.format(date: date)

        // 正規表現で形式を確認
        let regex = try! NSRegularExpression(pattern: #"^\d{2}:\d{2}:\d{2}\.\d{3}$"#)
        let range = NSRange(result.startIndex..., in: result)
        XCTAssertNotNil(
            regex.firstMatch(in: result, range: range),
            "フォーマットが 'HH:MM:SS.mmm' になっていない: \(result)"
        )
    }

    /// 時・分・秒・ミリ秒が正しく埋め込まれること
    func test_format_correctValues() {
        var comps        = DateComponents()
        comps.hour       = 9
        comps.minute     = 8
        comps.second     = 7
        comps.nanosecond = 6_000_000    // 6 ms

        let date   = Calendar.current.date(from: comps)!
        let result = TimerViewModel.format(date: date)
        let parts  = TimeParts(result)!

        XCTAssertEqual(parts.hh,  9,  "hour")
        XCTAssertEqual(parts.mm,  8,  "minute")
        XCTAssertEqual(parts.ss,  7,  "second")
        XCTAssertEqual(parts.sss, 6,  "millisecond")
    }

    /// 境界値: 0時0分0秒0ms
    func test_format_midnight() {
        var comps        = DateComponents()
        comps.hour       = 0; comps.minute = 0; comps.second = 0; comps.nanosecond = 0

        let result = TimerViewModel.format(date: Calendar.current.date(from: comps)!)
        XCTAssertEqual(result, "00:00:00.000")
    }

    /// 境界値: 23時59分59秒999ms
    func test_format_endOfDay() {
        var comps        = DateComponents()
        comps.hour       = 23; comps.minute = 59; comps.second = 59
        comps.nanosecond = 999_000_000

        let result = TimerViewModel.format(date: Calendar.current.date(from: comps)!)
        XCTAssertEqual(result, "23:59:59.999")
    }

    /// 2桁ゼロパディング: 時・分・秒がひと桁のとき "0x" になること
    func test_format_zeroPadding() {
        var comps  = DateComponents()
        comps.hour = 1; comps.minute = 2; comps.second = 3; comps.nanosecond = 4_000_000

        let result = TimerViewModel.format(date: Calendar.current.date(from: comps)!)
        XCTAssertEqual(result, "01:02:03.004")
    }

    /// ミリ秒3桁ゼロパディング: 1ms → "001"
    func test_format_millisecondZeroPadding() {
        var comps        = DateComponents()
        comps.hour       = 12; comps.minute = 0; comps.second = 0
        comps.nanosecond = 1_000_000   // 1 ms

        let result = TimerViewModel.format(date: Calendar.current.date(from: comps)!)
        let parts  = TimeParts(result)!
        XCTAssertEqual(parts.sss, 1, "1ms が \(parts.sss) になっている")
        XCTAssertTrue(result.hasSuffix(".001"), "末尾が '.001' であること: \(result)")
    }

    // ────────────────────────────────────────────
    // MARK: 2. tick() — timeString が更新されること
    // ────────────────────────────────────────────

    /// tick() を呼ぶと timeString が更新されること
    func test_tick_updatesTimeString() async {
        var comps        = DateComponents()
        comps.hour       = 10; comps.minute = 20; comps.second = 30
        comps.nanosecond = 456_000_000

        let fixedDate = Calendar.current.date(from: comps)!
        let vm = TimerViewModel(clock: fixedClock(fixedDate))

        vm.tick()

        XCTAssertEqual(vm.timeString, "10:20:30.456")
    }

    /// tick() を複数回呼ぶたびに最新のクロック値が反映されること
    func test_tick_multipleCallsReflectLatestTime() async {
        var returnSecond = 0
        let dynamicClock: () -> Date = {
            var comps  = DateComponents()
            comps.hour = 0; comps.minute = 0
            comps.second     = returnSecond
            comps.nanosecond = 0
            return Calendar.current.date(from: comps)!
        }

        let vm = TimerViewModel(clock: dynamicClock)

        returnSecond = 1; vm.tick()
        XCTAssertEqual(vm.timeString, "00:00:01.000", "1回目")

        returnSecond = 2; vm.tick()
        XCTAssertEqual(vm.timeString, "00:00:02.000", "2回目")

        returnSecond = 59; vm.tick()
        XCTAssertEqual(vm.timeString, "00:00:59.000", "3回目")
    }

    // ────────────────────────────────────────────
    // MARK: 3. 初期値
    // ────────────────────────────────────────────

    /// 生成直後の timeString はプレースホルダー文字列であること
    func test_initialTimeString_isPlaceholder() {
        let vm = TimerViewModel()
        XCTAssertEqual(vm.timeString, "--:--:--.---")
    }

    // ────────────────────────────────────────────
    // MARK: 4. start / stop
    // ────────────────────────────────────────────

    /// start() 後、33ms 以上待つと timeString が更新されること
    func test_start_updatesTimeStringAfterInterval() async throws {
        let vm = TimerViewModel(interval: 0.033)
        vm.start()

        // 100ms 待機（最低3回 tick するはず）
        try await Task.sleep(nanoseconds: 100_000_000)

        // "--:--:--.---" から変化していれば OK
        XCTAssertNotEqual(vm.timeString, "--:--:--.---",
            "start() 後 100ms 経過しても timeString が初期値のまま")

        vm.stop()
    }

    /// stop() 後は timeString が変化しないこと
    func test_stop_freezesTimeString() async throws {
        let vm = TimerViewModel(interval: 0.033)
        vm.start()

        // 少し動かしてから停止
        try await Task.sleep(nanoseconds: 50_000_000)
        vm.stop()
        let snapshot = vm.timeString

        // さらに待っても変わらないはず
        try await Task.sleep(nanoseconds: 100_000_000)
        XCTAssertEqual(vm.timeString, snapshot,
            "stop() 後に timeString が変化した")
    }

    /// start() を2回呼んでも Timer が重複しないこと（クラッシュや異常増加が起きない）
    func test_start_idempotent() async throws {
        let vm = TimerViewModel(interval: 0.033)
        vm.start()
        vm.start()   // 2回目は無視されるべき

        try await Task.sleep(nanoseconds: 100_000_000)
        // クラッシュしないこと・文字列が有効なフォーマットであること
        let regex = try NSRegularExpression(pattern: #"^\d{2}:\d{2}:\d{2}\.\d{3}$"#)
        let range = NSRange(vm.timeString.startIndex..., in: vm.timeString)
        XCTAssertNotNil(regex.firstMatch(in: vm.timeString, range: range))
        vm.stop()
    }

    // ────────────────────────────────────────────
    // MARK: 5. Published プロパティの変更通知
    // ────────────────────────────────────────────

    /// tick() が呼ばれたとき @Published の objectWillChange が発火すること
    func test_tick_publishesChange() async {
        var comps  = DateComponents()
        comps.hour = 8; comps.minute = 0; comps.second = 0; comps.nanosecond = 0

        let vm     = TimerViewModel(clock: fixedClock(Calendar.current.date(from: comps)!))
        var count  = 0
        let cancel = vm.objectWillChange.sink { count += 1 }

        vm.tick()

        // Combine は同期的に通知するため即確認できる
        XCTAssertEqual(count, 1, "objectWillChange が1回発火すること")
        cancel.cancel()
    }
}
